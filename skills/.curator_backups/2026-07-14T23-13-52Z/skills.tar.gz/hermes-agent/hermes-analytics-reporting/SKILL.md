---
name: hermes-analytics-reporting
description: Generate structured daily/weekly reports from Hermes internal data — token usage via hermes insights + state.db SQL queries, API provider balance checks, cost estimation with provider pricing, and formatted report delivery. For cron jobs and on-demand analytics.
---

# Hermes Analytics Reporting

Generate structured usage reports from Hermes internal data sources. This skill covers the pattern of aggregating data from multiple Hermes-internal sources (insights CLI, state.db SQLite store, API provider balance endpoints), estimating costs, and formatting the result as a structured report — typically delivered via cron jobs.

## Data Sources

### 1. `hermes insights --days N`
The primary high-level overview. Returns sessions count, message count, tool calls, input/output tokens, model breakdown, platform breakdown, tool usage, skill usage, activity patterns, and notable sessions.

### 2. `~/.hermes/state.db` (SQLite)
For per-session token breakdowns that `hermes insights` doesn't expose (e.g., top 5 sessions by tokens, cache hit/miss splits, per-session API calls).

**Key tables:**
- `sessions`: `id`, `title`, `started_at` (Unix timestamp), `model`, `input_tokens`, `output_tokens`, `cache_read_tokens`, `cache_write_tokens`, `message_count`, `tool_call_count`, `api_call_count`, `handoff_platform`, `estimated_cost_usd`
- `messages`: `id`, `session_id`, `role`, `token_count`, `timestamp` (Unix timestamp)

**Two approaches for date filtering:**

Approach A — filter by `started_at` (simpler, but may miss sessions that span the boundary):
```python
from datetime import datetime, timezone
start = (datetime.now(timezone.utc).timestamp() - 86400)
sessions = conn.execute("""
    SELECT ... FROM sessions 
    WHERE started_at >= ?
""", (start,))
```

Approach B — join through messages table (more accurate, catches sessions that started before but had activity in range):
```python
from datetime import datetime, timezone
start = datetime.now(timezone.utc).timestamp() - 86400
sessions = conn.execute("""
    SELECT DISTINCT m.session_id, s.input_tokens, s.output_tokens, 
           s.cache_read_tokens, s.started_at
    FROM messages m
    JOIN sessions s ON s.id = m.session_id
    WHERE m.timestamp >= ?
    ORDER BY (s.input_tokens + s.output_tokens) DESC
""", (start,))
```
Approach B often returns 2-4 more sessions than Approach A, matching the `hermes insights` count more closely.

**Platform detection:**
- Cron sessions: `id LIKE 'cron_%'`
- Gateway/Telegram sessions: `handoff_platform` may be NULL even for non-CLI sessions; cross-reference with `hermes insights` platform breakdown for accuracy
- CLI: everything else

**Token columns:**
| Column | Meaning | Billed at |
|--------|---------|-----------|
| `input_tokens` | Prompt tokens (cache miss) | Full input rate |
| `cache_read_tokens` | Prompt tokens served from provider cache | ~20× cheaper |
| `output_tokens` | Visible response tokens | Full output rate |
| `reasoning_tokens` | Chain-of-thought tokens (Anthropic only) | Output rate |
| `estimated_cost_usd` | **Often NULL** — do not rely on this | — |

**$estimated_cost_usd is usually NULL** — DeepSeek and many providers do not return cost data in the API response. Never use this column. Always compute cost manually from token counts and published pricing.

### 3. API Provider Balance

**DeepSeek:**
```bash
curl -s https://api.deepseek.com/user/balance \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY"
```
Returns: `is_available`, `balance_infos[]` with `currency`, `total_balance`, `granted_balance`, `topped_up_balance`.

**OpenRouter:**
```bash
curl -s https://openrouter.ai/api/v1/auth/key \
  -H "Authorization: Bearer $OPENROUTER_API_KEY"
```

Response format:
```json
{
  "data": {
    "label": "sk-or-v1-...",
    "is_free_tier": true,
    "limit": null,
    "limit_remaining": null,
    "usage": 0.116720026,
    "usage_daily": 0,
    "usage_weekly": 0,
    "usage_monthly": 0.116720026,
    "is_free_tier": true
  }
}
```

Key fields:
- `is_free_tier`: true → no hard spending cap (free tier is usage-based, not prepaid)
- `limit` / `limit_remaining`: null → no configured limit on this key
- `usage`: total lifetime spend through OpenRouter (not reset period)
- `usage_monthly`: spend this month through OpenRouter (resets monthly)
- The free tier has no explicit limit — it works until credits or rate limits are exhausted

### 4. Provider Pricing (for Cost Estimation)

Fetch from provider docs. For **DeepSeek V4 Flash** (as of June 2026):

| Component | Price |
|-----------|-------|
| Input (cache hit) | $0.0028 / 1M tokens |
| Input (cache miss) | $0.14 / 1M tokens |
| Output | $0.28 / 1M tokens |

Source: https://api-docs.deepseek.com/quick_start/pricing

## DeepSeek Thinking/Reasoning Tokens — Critical Cost Factor

**For DeepSeek reasoning models** (deepseek-v4-flash, deepseek-r1, etc.) in default thinking mode, the "Total tokens" reported by `hermes insights` is NOT input + output. It includes **thinking tokens** (the chain-of-thought that the model generates internally before the visible response).

**Typical breakdown (actual data from cron sessions):**

| Component | Tokens | % of total | Billed at |
|-----------|--------|-----------|-----------|
| Input tokens | 93,321 | 9.5% | $0.14/1M (cache miss) |
| Output tokens (visible) | 13,542 | 1.4% | $0.28/1M |
| Thinking tokens (hidden) | 874,496 | 89.1% | $0.28/1M (output rate) |
| **Total billed** | **981,359** | **100%** | — |

**Thinking tokens are charged at the output rate** ($0.28/1M for DeepSeek V4 Flash). This means 89% of the token count is at the most expensive tier. A cost estimate that ignores thinking tokens will be **~10x too low**.

**Detecting thinking tokens from `hermes insights`:**

```
Total tokens (from "Models Used" section) - Input tokens - Output tokens = Thinking tokens
981,359 - 93,321 - 13,542 = 874,496 thinking tokens
```

The `state.db` does NOT currently store thinking tokens in a separate column — they are baked into the provider-side billing but not exposed in `sessions.*_tokens` columns. Use the subtraction method above.

**To reduce thinking token cost:**
- Switch to **non-thinking mode** for simple tasks: `hermes config set model.thinking_mode false` (DeepSeek V4 Flash supports both modes)
- For cron jobs with deterministic execution (data collection, formatting, simple RAG), non-thinking mode can eliminate 90% of token cost
- Per-model, not global — set per-cron-job via `--thinking false` or cron config

## Cost Estimation Formula

**Important: Do NOT rely on `state.db`'s `estimated_cost_usd` column.** DeepSeek and many other providers do not return cost data in the API response. The column will be NULL or $0.00. Always compute cost manually from raw token counts and current provider pricing.

### Without thinking tokens (non-reasoning models or thinking disabled):

```
cache_hit_cost  = (cache_read_tokens / 1_000_000) * cache_hit_price
cache_miss_cost = (input_tokens / 1_000_000) * cache_miss_price
output_cost     = (output_tokens / 1_000_000) * output_price
total_cost      = cache_hit_cost + cache_miss_cost + output_cost
cache_hit_rate  = cache_read_tokens / (input_tokens + cache_read_tokens)
```

### With thinking tokens (DeepSeek reasoning models, default mode):

```
# thinking_tokens = total_tokens - input_tokens - output_tokens
# or from provider API: usage.completion_tokens_details.thinking_tokens

cache_hit_cost    = (cache_read_tokens / 1_000_000) * cache_hit_price
cache_miss_cost   = (input_tokens / 1_000_000) * cache_miss_price
output_cost       = (output_tokens / 1_000_000) * output_price
thinking_cost     = (thinking_tokens / 1_000_000) * output_price  # billed at output rate!
total_cost        = cache_hit_cost + cache_miss_cost + output_cost + thinking_cost
```

For DeepSeek V4 Flash:
- Cache hit rate is typically very high (~97%) for repeated cron sessions with identical system prompts
- Thinking token ratio varies by task complexity. Cron jobs reporting structured data: ~5-10x output tokens. Complex reasoning tasks: 20-50x+

## Report Format Template

Use this format for the actual delivery. It's been refined through real cron deliveries to be scannable, compact, and complete — a table-based cost breakdown tends to be too wide for most delivery channels (Telegram, gateways, CLI output).

Always start with the emoji header line. Use Chinese throughout. Include a brief summary paragraph at the end with actionable suggestions.

```
📊 Token 消耗日报 — {date}（{weekday}）
---

**今日总消耗：{actual_input_output:,} tokens**（输入 {input:,} + 输出 {output:,}）

> 另含缓存读取 {cache_read:,} tokens（已按优惠计费，计入总账单指标 {total_with_cache:,}）

### 按模型分

| 模型 | Sessions | Tokens |
|------|----------|--------|
| {model} | {count} | {total:,}（含缓存） |

### 按平台分

| 平台 | Sessions | Messages | Tokens |
|------|----------|----------|--------|
| {platform} | {count} | {msgs} | {total:,} |

> 如需平台细分，使用 cron 检测：`id LIKE 'cron_%'`；Telegram 参照 insights CLI 输出。

### 按会话分（Top {N}）

| # | 会话 ID | 输入 | 输出 | 合计 |
|---|---------|------|------|------|
| 1 | `{session_id_short}` | {input:,} | {output:,} | **{total:,}** |
| 2 | ... | ... | ... | **...** |

最长会话 {max_duration}，最活跃会话 {max_messages} 条消息 / {max_calls} 次工具调用。

### 热门工具调用 Top {N}

| 工具 | 调用次数 | 占比 |
|------|---------|------|
| `{tool}` | {calls} | {pct}% |
| ... | ... | ... |

### 余额情况

| 项目 | 数值 |
|------|------|
| API Provider | {provider} |
| 账户余额 | **{balance} {currency}** |
| 充值余额 | {topped_up} |
| 赠送余额 | {granted} |
| 账户状态 | ✅ 可用 |

> 按今日消耗速率（约 ¥{daily_rate}/天），余额可维持约 {days} 天。
> {optional_suggestion_about_thinking_mode_or_rate}

### 💡 总结与建议

- 要点 1：xx
- 要点 2：xx
- 建议：xx
```

### Compact version（用于简短投递）

When the delivery channel prefers shorter content (e.g. gateway inline notifications, cron delivery):

```
📊 Token 消耗日报 — {date}（{weekday}）

今日总消耗：{total:,} tokens
- 会话数 {sessions}
- tool calls {tool_calls} 次，消息 {messages} 条

按模型分：
- {model}: {total:,} tokens（{sessions} 个会话）

按平台分：
- {platform}: {total:,} tokens（{sessions} 个会话，{pct}%）
- ...

按会话分（Top 5）：
1. {id_short} — {tokens:,} tokens ({platform})
2. ...

使用最多的工具：
- {tool}: {calls} 次
- ...

剩余情况：
- DeepSeek: {balance} CNY（可用）
- OpenRouter: 免费套餐（本月已用 ${openrouter_usage}）

💡 总结与建议
...
```

### Cron-delivery variant（用户请求的格式）

When the user explicitly asked for this specific structure (identified by the cron job instruction template), use this exact format — it's the one delivered via cron and has been validated over successive runs:

```text
📊 Token 消耗日报

今日总消耗：{total:,} tokens

按模型分：
- {model_name}: {total:,} tokens

按平台分：
- {platform_name}: {total:,} tokens
- {platform_name}: {total:,} tokens

按会话分（消耗最多的前5个会话）：
1. {session_label} — {tokens:,} tokens
2. {session_label} — {tokens:,} tokens
3. {session_label} — {tokens:,} tokens
4. {session_label} — {tokens:,} tokens
5. {session_label} — {tokens:,} tokens

剩余情况：
- {provider}: {balance} {currency}（可用）

{one_paragraph_summary_and_suggestion}
```

Rules for this variant:
- **No markdown tables.** Use indented bullet lists (`- item`) for every breakdown section. Tables break on Telegram and some gateway channels.
- **"今日总消耗" = the `hermes insights` "Total tokens"** (includes cache reads + thinking tokens if applicable). This is the headline metric the user sees.
- **按模型分**: list only models with non-zero tokens. Typically just one (deepseek-v4-flash).
- **按平台分**: use the three standard sources — `cron`, `telegram`, `cli`. Sorted by token count descending.
- **会话标签**: for cron sessions, label as `Cron job ({short_id})` where `short_id` is the 12-char job identifier from the session ID (e.g., `cron_b8eb1e564ba8_20260712_220018` → `b8eb1e564ba8`). For CLI: `CLI 会话`. For Telegram: `Telegram 会话`.
- **剩余情况**: DeepSeek shows `{balance} CNY（可用）` where balance is from `curl https://api.deepseek.com/user/balance` → `balance_infos[0].total_balance`. If balance < 1.00 CNY, append `（即将耗尽，建议充值）`.
- **One paragraph summary only.** Not a list of bullet points — one flowing Chinese sentence or a short paragraph with 2-3 key observations. Keep it to 2-3 lines max.

**Example from actual cron delivery (2026-07-11):**

```
📊 Token 消耗日报 — 2026-07-11（周六）

今日总消耗：8,058,478 tokens
- 会话数 20
- tool calls 309 次，消息 585 条

按模型分：
- DeepSeek V4 Flash: 8,058,478 tokens (20/20 会话)

按平台分：
- Cron (定时任务): 7,268,932 tokens (15 会话, 90.2%)
- CLI (手动会话): 789,546 tokens (5 会话, 9.8%)

按会话分（Top 5）：
1. cron_b8eb1e564ba8_220003 — 1,185,652 tokens (skill invoke)
2. cron_e3b0ffccfa4a_220001 — 925,547 tokens (scheduled task, 100 msgs)
3. cron_e3b0ffccfa4a_150051 — 885,875 tokens (scheduled task, 120 msgs)
4. cron_b8eb1e564ba8_200046 — 699,920 tokens (skill invoke)
5. cron_b8eb1e564ba8_160216 — 606,134 tokens (skill invoke)

使用最多的工具：
- terminal — 263 次 (85.1%)
- execute_code — 16 次 (5.2%)
- write_file — 14 次 (4.5%)

剩余情况：
- DeepSeek: 0.60 CNY（可用，但即将耗尽）
- OpenRouter: 免费套餐（本月已用 $0.1167，无额度限制）

💡 总结与建议
- Cron 任务消耗了 90% 的 tokens，集中在两个定时任务
- 缓存命中率 90%，大幅降低了实际成本
- DeepSeek 余额仅剩 0.60 CNY，建议尽快充值
- 如 cron 任务关闭 thinking 模式，可节省 ~90% 成本
```

### Summary paragraph patterns

End every report with a short self-contained paragraph:

```python
summary_parts = [
    f"- **今日全部消耗来自 {platform}**（{skill_names_used}），日均约 {runs_per_day} 轮执行。",
]
if cache_hit_rate > 0.9:
    summary_parts.append(f"- **缓存命中率极高** — {cache_read:,} cache read vs {input_miss:,} 新输入（约 {cache_hit_rate:.0%} 缓存率），说明 {provider} 的上下文缓存机制非常有效，大幅降低了实际成本。")
if thinking_pct > 0.3:
    summary_parts.append(f"- **推理思考 tokens 占比 {thinking_pct:.0%}** — 如 cron 任务无需深度推理，关闭 thinking 模式可节省 ~90% 成本。")
if days_remaining < 7:
    summary_parts.append(f"- **余额仅可维持约 {days_remaining} 天** — 建议关注充值时机。")
elif days_remaining > 30:
    summary_parts.append(f"- **余额充足**（约 {days_remaining} 天），短期内无需充值。")
else:
    summary_parts.append(f"- 余额约可维持 {days_remaining} 天，暂无充值压力。")
```

All headings use emoji headers (📊, 💰, 📝, 💡). Use Chinese for user-facing report text.

## Clock and Timezone Awareness

When running as a cron job:
- `datetime.now(timezone.utc)` gives UTC time
- The Hermes insights CLI uses localtime for its `--days` display
- `state.db` stores `started_at` as UTC Unix timestamps (floats)
- When querying state.db, use UTC timestamp ranges to match `--days 1`

## Pitfalls

- **`hermes insights` reports a different "Total tokens" than the sum of state.db.** The insights tool may include or exclude cache tokens differently from the raw DB columns. The DB `cache_read_tokens` column holds the tokens served from provider cache (billed at lower rate, not free). Cross-referencing both sources is recommended.
- **Thinking tokens make "Total tokens" misleading.** For DeepSeek reasoning models, `hermes insights` "Total tokens" = input + output + thinking tokens. The state.db `input_tokens` + `output_tokens` will sum to much less than the model's total. Always subtract to find thinking tokens before estimating cost — ignoring them leads to ~10x underestimation.
- **DB `reasoning_tokens` may be 0 even when thinking tokens are present.** DeepSeek's thinking tokens are reported in the API completion response differently from Anthropic's `extended_thinking`. The `state.db` `reasoning_tokens` column may be 0 while `hermes insights` "Total tokens" still shows the inflated count.

**CRITICAL NUANCE: `insights_total - input - output` gives `cache_read + thinking`, NOT just thinking.** You must check `state.db`'s `cache_read_tokens` to distinguish them. If `cache_read_tokens` ≈ `insights_total - input - output`, there are NO significant thinking tokens — the gap is all cache reads. If `cache_read_tokens` is much smaller than the gap, the remainder is thinking tokens.

Example: today's data (2026-07-12, thinking mode disabled):
- insights_total: 8,515,211
- input: 739,315 | output: 245,528
- Delta: 7,530,368
- DB cache_read_tokens: 7,782,528 (matching delta within window shift)
- reasoning_tokens in DB: 0 for ALL sessions
- **Conclusion: no thinking tokens — the delta is all cache reads**

Compare with pre-mitigation data (2026-06-29, thinking mode enabled):
- Delta: 874,496
- cache_read_tokens: ~0 (not significant)
- **Conclusion: delta IS thinking tokens**

So: subtraction method first to get the raw delta, THEN cross-reference with DB `cache_read_tokens`. If cache_read_tokens ≈ delta → no thinking tokens. If cache_read_tokens ≪ delta → thinking tokens = delta - cache_read_tokens.
- **`handoff_platform` is often NULL** for Telegram sessions. The insights CLI has better platform detection. Use insights for platform totals and DB for session-level detail.
- **Balance API keys** are in `~/.hermes/.env`, not in environment variables. Read them from the file or source them.
- **`estimated_cost_usd` and `actual_cost_usd` in state.db may be NULL or $0.00** even for sessions with thousands of tokens. These fields are populated only when the provider API returns cost data in the OpenAI-compatible usage response format. DeepSeek often does NOT return this. Never rely on these columns for actual cost — always compute manually from raw token counts and current provider pricing. The DB only has reliable token counts; discard cost columns entirely.
- **`sqlite3` CLI tool may not be installed** on the system. Use Python's built-in `sqlite3` module instead (`import sqlite3`) for all state.db queries. This is always available without additional dependencies.
- **`hermes insights` has no `--verbose` or `--json` flag.** The only parameter is `--days N`. For per-session token breakdowns not shown in the summary view, you must query `state.db` directly with SQL. `hermes sessions list` also lacks `--json` output.
- **Date filter mismatch between `hermes insights` and state.db.** The insights CLI uses a 24-hour sliding window from localtime. The `state.db` `started_at` is a UTC Unix timestamp. Use a UTC timestamp range for SQL queries: `datetime.now(timezone.utc).timestamp() - 86400` to `datetime.now(timezone.utc).timestamp()`. The sessions count may differ by 1-4 sessions between the two sources because of this.
- **First-run pricing lookup** may require scraping the provider docs page. Cache the prices in the skill or reference doc to avoid re-scraping every time.
- **Rounding**: cost estimations are approximate — provider rounding differs from naive division. Add a disclaimer.
- **Multiple cron job IDs per system**: A single cron schedule may produce sessions with different ID prefixes (`cron_b8eb1e564ba8`, `cron_e3b0ffccfa4`, `cron_a1d0d341b0bd`, etc.) — each prefix corresponds to a different cron job definition. When reporting per-session breakdowns, group by the full ID prefix (first 24-32 chars before the timestamp) to distinguish distinct jobs, rather than a single `cron_%` wildcard.
- **Balance critically low** (<1.00 CNY): The `is_available` field remains `true` but depletion is imminent (<1 day). Flag this explicitly as "余额即将耗尽" and suggest: (a) recharging, (b) switching to OpenRouter fallback, or (c) disabling thinking mode on cron jobs for 10x cost reduction. When estimated days remaining is <1.0, switch to hours or check per-report instead.

## See Also

- `references/hermes-token-report.md` — Complete worked example: token usage report with DB queries and cost estimation
- `references/deepseek-thinking-tokens-cost.md` — DeepSeek thinking token cost factor: detection formula, raw data from actual sessions, and mitigation (used when `hermes insights` "Total tokens" hugely exceeds input+output)
- `references/report-calibration-point-20260711.md` — Real session data from 2026-07-11 showing critically low balance (0.60 CNY), 87% thinking token ratio, 90% cache hit rate, and OpenRouter free tier details. Useful as a calibration reference for balance depletion rates.
- `references/calibration-20260712-post-mitigation.md` — Post-mitigation baseline from 2026-07-12: thinking mode disabled on cron jobs, zero thinking tokens across all sessions, balance at ¥6.84 CNY with ~45 days remaining. Comparison table showing before/after cost reduction.
- `hermes-agent` skill (bundled) — `hermes insights` CLI reference and session management
- `cron-state-persistence` — State persistence for delta/diff cron jobs
