# Calibration Point: July 11, 2026

Real session data from 2026-07-11. Useful as a calibration reference — this shows
the balance state after ~2 weeks of daily cron operation, and how the cache hit rate
and thinking token ratio look in an established usage pattern.

## `hermes insights --days 1` Output

```
Period: Jul 11, 2026 — Jul 11, 2026

Sessions:          20            Messages:        585
Tool calls:        309           User messages:   19
Input tokens:      833,469       Output tokens:   215,729
Total tokens:      8,058,478
Active time:       ~2h 3m        Avg session:     ~9m
Avg msgs/session:  29.2

Model                    Sessions       Tokens
deepseek-v4-flash              20    8,058,478

Platform       Sessions   Messages         Tokens
cron                 15        520      7,268,932
cli                   5         65        789,546

Longest session      13m                (cron_e3b0ffccfa4)
Most messages        120 msgs           (cron_e3b0ffccfa4)
Most tokens          111,760 tokens     (cron_b8eb1e564ba)
Most tool calls      66 calls           (cron_e3b0ffccfa4)
```

## SQL State DB Query

```sql
-- Sessions matching date() filter: 18 sessions, 7,785,066 tokens
-- hermes insights reports 20 sessions — the 2 extra likely had messages
-- in range but started before midnight
SELECT date(started_at, 'unixepoch'), COUNT(*),
       SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0) + COALESCE(cache_read_tokens,0))
FROM sessions
GROUP BY 1
ORDER BY 1 DESC
LIMIT 5;
```

Results:
- 2026-07-11: 18 sessions, 7,785,066 tokens
- 2026-07-10: 11 sessions, 13,327,303 tokens
- 2026-07-09: 7 sessions, 11,815,204 tokens

Note: session count trended up from 7 to 18 over 2 days — this reflects increasing
cron job activity, not drift.

## Token Breakdown

| Component | Count | % of "Total" |
|-----------|-------|--------------|
| Input (cache miss) | 729,255 | 9.0% |
| Output (visible) | 200,945 | 2.5% |
| Cache read | 6,819,456 | 84.2% |
| Total (DB sum) | 7,749,656 | — |
| Thinking tokens (inferred) | ~7,008,264 | 87.0% of insights total |
| **Insights total** | **8,058,478** | **100%** |

**Thinking token inference:**
```
thinking = 8,058,478 - 833,469 - 215,729 = 7,009,280
thinking_pct = 87.0%
```

**Cache hit rate:**
```
cache_hit_rate = 6,819,456 / (729,255 + 6,819,456) = 90.3%
```

## Cost Estimation

Using DeepSeek V4 Flash pricing:
- Input cache hit: $0.0028 / 1M
- Input cache miss: $0.14 / 1M
- Output (incl. thinking): $0.28 / 1M

| Component | Tokens | Price | Cost |
|-----------|--------|-------|------|
| Cache hit | 6,819,456 | $0.0028/M | $0.0191 |
| Input miss | 729,255 | $0.14/M | $0.1021 |
| Visible output | 200,945 | $0.28/M | $0.0563 |
| Thinking tokens | ~7,009,280 | $0.28/M | $1.9626 |
| **Total** | | | **$2.14 / ¥15.52** |

**Key takeaway:** Thinking tokens account for **$1.96 of $2.14 total cost (91.6%)**.
This is even more extreme than the June 28 example (89%). Without thinking mode,
this day would cost ~$0.18 instead of $2.14 — a **12x cost reduction**.

## Balance

**DeepSeek:** 0.60 CNY remaining (all topped-up, 0 granted)
- Daily cost: ~¥15.52/day (at current thinking-enabled rate)
- Days remaining: **<1 day** — critical state
- If thinking disabled: ~¥1.30/day → ~0.5 days (balance was already very low)

**OpenRouter (backup provider):** Free tier
- `is_free_tier: true`
- `limit: null` (no hard cap)
- `usage: $0.116720` (lifetime through OpenRouter; low because DeepSeek is primary)
- `limit_remaining: null` (no limit set on free tier)
- Rate limit: `-1 requests per 10s` (deprecated field, effectively unlimited)

## Active Cron Job IDs

From `hermes sessions list` on Jul 11, three distinct cron identifiers:

| ID Pattern | Sessions | Description |
|------------|----------|-------------|
| `cron_b8eb1e564ba8` | 8 | Skill-invocation tasks (loads a skill, runs it) |
| `cron_e3b0ffccfa4` | 4 | Scheduled research/analysis tasks |
| `cron_a1d0d341b0bd` | 1 | Historical daily pattern (has run daily since Jun 28) |

The `cron_a1d0d341b0bd` job runs daily at ~23:00 local time since late June,
and was still active on Jul 11. This identifies three active cron schedules.

## Notable Sessions Detail

| ID | Tokens | Platform | Description |
|----|--------|----------|-------------|
| cron_b8eb1e564ba8_220003 | 1,185,652 | cron | Skill invoke |
| cron_e3b0ffccfa4a_220001 | 925,547 | cron | Scheduled task (100 msgs) |
| cron_e3b0ffccfa4a_150051 | 885,875 | cron | Scheduled task (120 msgs, longest) |
| cron_b8eb1e564ba8_200046 | 699,920 | cron | Skill invoke |
| cron_b8eb1e564ba8_160216 | 606,134 | cron | Skill invoke |
