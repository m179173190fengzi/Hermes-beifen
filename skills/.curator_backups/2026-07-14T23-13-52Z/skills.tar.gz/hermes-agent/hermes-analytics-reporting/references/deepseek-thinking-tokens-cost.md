# DeepSeek Thinking Token Cost — Worked Example

Dedicated reference for the critical cost factor when using DeepSeek reasoning models
in thinking mode. Generated from actual cron session data on 2026-06-29.

## The Problem: Where Did All These Tokens Come From?

`hermes insights --days 1` reports:

| Metric | Value |
|--------|-------|
| Input tokens | 93,321 |
| Output tokens | 13,542 |
| **Total tokens** | **981,359** |

Input + Output = 106,863. But Total = 981,359. **Where did the extra 874,496 tokens come from?**

Answer: **thinking/reasoning tokens** — the internal chain-of-thought the model generates
before producing its visible response. DeepSeek V4 Flash runs in thinking mode by default.

## Cost Impact

DeepSeek V4 Flash pricing:

| Component | Price / 1M tokens |
|-----------|-------------------|
| Input (cache miss) | $0.14 |
| Output (visible) | $0.28 |
| **Thinking tokens** | **$0.28 (output rate!)** |

**Cost if you ignore thinking tokens:**
- Input (93,321 × $0.14/1M) = $0.013
- Output (13,542 × $0.28/1M) = $0.004
- **"Total" = $0.02** ← WRONG, 10x too low

**Real cost:**
- Input: $0.013
- Output: $0.004
- **Thinking (874,496 × $0.28/1M) = $0.245**
- **Real total = $0.26** ← 89% from thinking tokens!

## Detection Formula

```python
thinking_tokens = total_from_insights - input_tokens - output_tokens
# 981,359 - 93,321 - 13,542 = 874,496
thinking_pct = thinking_tokens / total_from_insights * 100
# 89.1%
thinking_cost = (thinking_tokens / 1_000_000) * 0.28
```

The `state.db` does NOT have a `thinking_tokens` column. The subtraction method
is the only way to get this number from Hermes data alone.

**⚠️ Important: the `reasoning_tokens` column in state.db is unreliable for DeepSeek models.**
DeepSeek reports thinking tokens in the API completion response differently than
Anthropic's `extended_thinking` mechanism. The `state.db` `reasoning_tokens` column
may be 0 even when `hermes insights` "Total tokens" clearly shows the inflated count
(thinking tokens baked into the total). Always use the subtraction method above — do NOT
check the DB `reasoning_tokens` column as a proxy for whether thinking tokens are present.

## Raw Data from This Session

```json
{
  "source": "hermes insights --days 1 (2026-06-29)",
  "period": "2026-06-28 to 2026-06-29",
  "inputs": {
    "input_tokens": 93321,
    "output_tokens": 13542,
    "total_from_insights": 981359,
    "thinking_tokens_inferred": 874496,
    "thinking_pct": 89.1
  },
  "cost_estimate": {
    "input_miss": 0.0131,
    "output": 0.0038,
    "thinking": 0.2449,
    "total_usd": 0.262,
    "total_cny": 1.89
  },
  "balance": {
    "currency": "CNY",
    "total_balance": "5.41",
    "granted_balance": "0.00",
    "topped_up_balance": "5.41",
    "days_remaining_at_rate": 2.9
  },
  "deepseek_pricing": {
    "input_cache_hit": 0.0028,
    "input_cache_miss": 0.14,
    "output": 0.28,
    "note": "thinking tokens billed at output rate"
  }
}
```

## Mitigation

For cron jobs that only need deterministic output (data summarization, report formatting,
simple lookup queries), **disable thinking mode** to save ~90% on token costs:

```bash
# Global config
hermes config set model.thinking_mode false

# Per-cron job (thinking mode off by default in cron)
```

When thinking mode is off, the cost breakdown looks like:
- Input: $0.013 (unchanged)
- Output: $0.004 (unchanged)
- Thinking: $0.00 (eliminated)
- Total: ~$0.02 (10x cheaper)
