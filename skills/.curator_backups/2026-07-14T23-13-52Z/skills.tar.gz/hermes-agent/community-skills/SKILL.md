---
name: community-skills
description: Discover, evaluate, and install community skills packs for Hermes Agent from GitHub and ecosystem registries.
category: hermes-agent
triggers:
  - "find skill"
  - "install skill"
  - "github skill"
  - "awesome hermes"
  - "superpowers"
  - "community skill"
  - "skill pack"
  - "装skill"
  - "skills包"
---

# Community Skills — Discovery & Installation

Find and install community-built skills packs for Hermes Agent.

## Discovery Sources

| Source | URL | Type |
|--------|-----|------|
| awesome-hermes-agent | https://github.com/0xNyk/awesome-hermes-agent | Curated list (4.6k⭐) |
| GitHub search | https://github.com/search?q=hermes+agent+skill&type=repositories&s=stars&o=desc | Raw search |
| hermeshub | https://github.com/amanning3390/hermeshub | Community hub |
| skilldock.io | https://skilldock.io | Cross-platform registry |
| agentskills.io | https://agentskills.io | Open standard ecosystem |

## Install superpowers-zh (中文增强版)

The most popular Chinese-localized skills pack (20 skills, Hermes-compatible).

```bash
# RECOMMENDED — full install with hooks + bootstrap
cd /your/project
npx superpowers-zh --tool hermes
```

This creates `.hermes/skills/` with 20 skills + `HERMES.md` bootstrap.

### Pitfalls

- **DO NOT run in `~`** — it writes bootstrap files to your home directory, polluting all projects. Always run inside a project directory.
- **Manual `cp -r skills` is low-fidelity** — doesn't configure hooks or bootstrap. The AI won't auto-trigger skills. Use `npx superpowers-zh` when possible.
- **If already mistakenly run in `~`**: delete `~/skills/` and `~/HERMES.md` / `~/CLAUDE.md`.

### Merge into Production Hermes

```bash
cp -r /path/to/project/.hermes/skills/* ~/.hermes/skills/
```

## Install Skills from awesome-hermes-agent

Each entry in awesome-hermes-agent has a maturity tag:

- `production` — stable, safe to build on
- `beta` — works but evolving
- `experimental` — proof of concept

Installation varies by skill. Common patterns:

```bash
# GitHub-based skills
git clone https://github.com/<user>/<repo>.git /tmp/<repo>
cp -r /tmp/<repo>/skills/* ~/.hermes/skills/

# npm-based (like superpowers-zh)
npx <package-name> --tool hermes

# hermes skills tap (rare)
hermes skills tap add <user>/<repo>
```

## Evaluating Community Skills

Checklist before installing:

1. **README quality** — clear description, install instructions, examples
2. **Maturity** — production > beta > experimental
3. **Last commit** — active in last 3 months
4. **Stars** — signal but not requirement
5. **License** — MIT preferred for compatibility
6. **Test coverage** — tests = maintained
7. **Skill format** — follows SKILL.md standard with proper frontmatter

## Chinese-Focused Community Skills

Especially useful for Chinese-speaking users:

| Pack | Skills | Install |
|------|--------|---------|
| superpowers-zh | 20 skills (14 translated + 6 original) | `npx superpowers-zh --tool hermes` |
| hermes-skills (winterliu6) | content-studio, security-newsletter, tech-ops-bot | GitHub clone |
| hermes-feishu-zh (plugin) | Feishu display fixes + lark-cli-toolbox | `hermes plugins install` |

## This Session's Discoveries (2026-07-13)

Nine community projects evaluated and partially installed:

| Project | Stars | Type | Installed |
|---------|:-----:|:----:|:---------:|
| hermes-workspace | 6,050 | Web UI | ✅ `~/hermes-workspace/` |
| super-hermes | 307 | Skills (prism) | ✅ 5 skills + 7 prisms |
| hermes-dojo | 117 | Skills + scripts | ✅ `~/.hermes/skills/hermes-dojo/` |
| oh-my-hermes | 105 | Skills pack (4 skills) | ❌ optional |
| hermes-dashboard | 62 | Plugin + Web UI | ❌ skipped (dashboard_auth missing) |
| hermes-achievements | 42 | Plugin (dashboard addon) | ❌ skipped (depends on dashboard) |
| hermes-skill-marketplace | 42 | Skills + scripts | ❌ optional |
| hermes-spotify-skill | 10 | Skill | ❌ optional |
| blacktea | 5 | MCP + lib | ❌ not relevant |

See `references/hermes-ecosystem-catalog-20260713.md` for full descriptions and install notes.

### Install Patterns Used This Session

| Pattern | Example | When to Use |
|---------|---------|-------------|
| `git clone → install.sh` | super-hermes, hermes-dojo | Has `install.sh` in repo root |
| `git clone → pnpm install → pnpm build → node server-entry.js` | hermes-workspace | Standalone web app, not a Hermes skill |
| `git clone → cp skills/ ~/.hermes/skills/` | Generic | Bare skills without install script |
| `hermes dashboard --port 9119` | Built-in dashboard | Fails if `dashboard_auth` module missing |

### Workspace Notes

- Runs on `node server-entry.js` from project root
- Starts on `http://127.0.0.1:3000`
- Needs Hermes Gateway HTTP API running (`API_SERVER_ENABLED=true` + `API_SERVER_KEY` in `~/.hermes/.env`)
- Dashboard-backed APIs (`/api/sessions`, enhanced chat, memory, jobs) require `hermes dashboard` on :9119
- If `dashboard_auth` module is missing, the core features (chat, terminal, memory, skills) still work fine
- The workspace also pairs with `hermes gateway run` for live session streaming

### Super Hermes Notes

- Installs 5 prism skills + 7 proven prisms under `~/.hermes/prisms/`
- Commands: `/prism-scan`, `/prism-full`, `/prism-3way`, `/prism-discover`, `/prism-reflect`
- Prisms can also be used as standalone system prompts with any tool
- Tested on Gemini 2.5 Flash, Claude Sonnet, Hermes 3/Llama 405B

### Hermes Dojo Notes

- Installs to `~/.hermes/skills/hermes-dojo/` with scripts/ and references/
- Quick test: `cd ~/.hermes/skills/hermes-dojo/scripts && python3 seed_demo_data.py --days 7 && python3 demo.py --reset`
- In Hermes: `/dojo analyze`

## Related

- `~/demo-superpowers/` — reference installation from this session
- `awesome-hermes-agent` — full ecosystem catalog, includes 100+ entries across skills, plugins, memory providers, deployment, integrations
- `~/hermes-workspace/` — installed web workspace
- `~/super-hermes/` — installed prism skills source
- `~/hermes-dojo/` — installed dojo source
