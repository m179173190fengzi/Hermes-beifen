# Hermes Vision/Auxiliary Configuration

## Enabling Image Recognition

Hermes needs a vision-capable model to analyze images. The current model (DeepSeek) doesn't support vision.

### Configuration

```bash
# Set the auxiliary vision provider
hermes config set auxiliary.vision.provider google
hermes config set auxiliary.vision.model gemini-2.0-flash

# Or for OpenRouter (supports many models):
hermes config set auxiliary.vision.provider openrouter
hermes config set auxiliary.vision.model google/gemini-2.0-flash
```

### API Key

Add to `~/.hermes/.env`:

```
GEMINI_API_KEY=<your_key>
# OR
OPENROUTER_API_KEY=<your_key>
```

### Restart

```bash
systemctl --user restart hermes-gateway
```

### Required Tools

The `vision` toolset must be enabled:
```bash
hermes tools enable vision
```

### Troubleshooting

If images are still not processed after configuration:

1. Check the auxiliary vision config in `~/.hermes/config.yaml`:
   ```bash
   grep -A 10 "auxiliary:" ~/.hermes/config.yaml
   ```

2. Verify the API key is in `.env`:
   ```bash
   grep -i "GEMINI\|OPENROUTER" ~/.hermes/.env
   ```

3. Check gateway logs for errors:
   ```bash
   grep -i "vision\|auxiliary" ~/.hermes/logs/gateway.log | tail -10
   ```
