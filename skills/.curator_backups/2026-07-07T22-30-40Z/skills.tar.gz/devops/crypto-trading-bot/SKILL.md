---
name: crypto-trading-bot
category: devops
tags: [freqtrade, okx, futures, trading, automated-trading, crypto, low-time-investment, passive-monitoring]
triggers:
  - "install freqtrade"
  - "set up crypto trading bot"
  - "OKX 合约"
  - "automated trading"
  - "crypto trading bot setup"
  - "碎片化时间"
  - "低时间投入"
  - "上班族打狗"
linked_files:
  - references/okx-futures-config.md: OKX 合约配置文件模板说明
  - templates/freqtrade.sh: 便捷启动脚本
  - templates/sample-futures-strategy.py: 支持做空的 RSI 合约策略示例
  - templates/six-ma-cluster-strategy.py: 六均线密集交易系统
  - templates/low-time-crypto-approach.md: 碎片化时间用户打法指南（低时间投入+监控模式）
  - scripts/test-okx-connection.py: OKX API 凭证验证脚本
description: Set up and configure automated cryptocurrency trading bots. Covers FreqTrade setup, OKX futures config, strategy authoring, backtesting, AND low-time-investment passive monitoring for users with limited screen time. Install guide with proxy workarounds for China/GFW.
---

# Crypto Trading Bot Setup (FreqTrade)

## Overview

FreqTrade — open-source crypto trading bot. Support OKX spot and isolated futures.

## Quick Install (Native Python — Preferred for China/GFW)

```bash
git -c http.proxy=http://127.0.0.1:7890 -c https.proxy=http://127.0.0.1:7890 clone --depth 1 https://github.com/freqtrade/freqtrade.git
cd freqtrade
HTTP_PROXY=http://127.0.0.1:7890 HTTPS_PROXY=http://127.0.0.1:7890 ./setup.sh -i
```

## CLI Syntax Note (FreqTrade 2026.x)

`-c` goes **after** subcommand:
```bash
freqtrade trade -c config.json
freqtrade backtesting -c config.json --strategy SampleStrategy
```

## Proxy Config

```json
{
  "exchange": {
    "name": "okx",
    "ccxt_config": {
      "httpProxy": "http://127.0.0.1:7890",
      "timeout": 60000
    }
  }
}
```

Both `httpProxy` AND `timeout` must be listed together — FreqTrade drops httpProxy when it adds its own timeout key.

## Low-Time-Investment Mode

For users with limited screen time (~10min/day) who want passive monitoring:

1. See `templates/low-time-crypto-approach.md` for the full playbook
2. Use GMGN trending + cron alerts for token discovery
3. Set cronjob for MC thresholds: `--min-marketcap 100000`
4. Only check results when alerts fire — no active screen-watching

## Signal-Only Monitoring

```bash
python3 -c "
import ccxt
okx = ccxt.okx({'httpProxy': 'http://127.0.0.1:7890'})
ticker = okx.fetch_ticker('BTC/USDT')
print(f'BTC: ${ticker[\"last\"]} | 24h: {ticker[\"percentage\"]:.1f}%')
"
```

## PATH Setup

```bash
mkdir -p ~/bin
ln -sf ~/ft_userdata/freqtrade/.venv/bin/freqtrade ~/bin/freqtrade
```

## Quick Reference

| Task | Command |
|------|---------|
| List exchanges | `freqtrade list-exchanges -c config.json` |
| Download data | `freqtrade download-data -t 5m --days 30 -c config.json` |
| Backtest | `freqtrade backtesting --strategy SampleStrategy -c config.json` |
| Start trade | `freqtrade trade -c config.json` |
| FreqUI | `freqtrade webserver -c config.json --userdir ./user_data` |
