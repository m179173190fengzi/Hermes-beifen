# FLClash + Telegram Gateway in China

## Context

Session 2026-06-24: User diagnosed why Telegram bot wasn't responding.
FLClash (FlClashCore) was running as the proxy client on this system.

## FLClash Process Discovery

```bash
ps aux | grep -i clash
# → /usr/bin/FlClash (GUI)
# → /usr/share/FlClash/FlClashCore /tmp/FlClashSocket_6239.sock (core)

ss -tlnp | grep clash
# → LISTEN 0 4096 127.0.0.1:7890
```

FLClash uses Clash Meta kernel. Default mixed proxy port is **7890**
(HTTP + SOCKS5 on the same port).

## Proxy Config for Gateway

Added to `~/.hermes/.env`:

```
export HTTP_PROXY=http://127.0.0.1:7890
export HTTPS_PROXY=http://127.0.0.1:7890
export ALL_PROXY=socks5://127.0.0.1:7890
```

## Log Progression

1. Before extras fix:
   `Platform 'Telegram' requirements not met (pip install 'hermes-agent[telegram]')`

2. After extras fix, before proxy:
   `telegram connect timed out after 30s`
   `DoH discovery yielded no usable IPs (system DNS: 208.43.237.140)`

3. After proxy configured (expected, not observed in this session):
   `[Telegram] Connected`

## Key Insight

The `reconnection watcher` retries automatically every ~30s, so even
if the gateway starts without a proxy configured, adding proxy + restarting
(as opposed to waiting for retry) is the right fix.
