---
name: crypto-trading-bot
category: devops
tags: [freqtrade, okx, futures, trading, automated-trading, crypto]
triggers:
  - "install freqtrade"
  - "set up crypto trading bot"
  - "OKX 合约"
  - "automated trading"
  - "crypto trading bot setup"
linked_files:
  - references/okx-futures-config.md: OKX 合约配置文件模板说明
  - templates/freqtrade.sh: 便捷启动脚本
  - templates/sample-futures-strategy.py: 支持做空的 RSI 合约策略示例
  - templates/six-ma-cluster-strategy.py: 六均线密集交易系统 (MA cluster + MA20/EMA20 exit)
  - scripts/test-okx-connection.py: OKX API 凭证验证脚本 (读取 config 并测试连接)
description: Set up and configure automated cryptocurrency trading bots, with focus on FreqTrade and OKX futures/contract trading. Covers strategy authoring (MA cluster, bearish alignment, daily trend filter), backtesting workflow, proxy configuration, and credential verification.
---

# Crypto Trading Bot Setup (FreqTrade)

## Overview

Use [FreqTrade](https://github.com/freqtrade/freqtrade) — the leading open-source crypto trading bot (51.8k stars). Supports OKX spot and isolated futures.

## Quick Install (Native Python — Preferred for China/GFW networks)

```bash
# Clone with proxy
git -c http.proxy=http://127.0.0.1:7890 -c https.proxy=http://127.0.0.1:7890 clone --depth 1 https://github.com/freqtrade/freqtrade.git
cd freqtrade

# Run setup (creates venv + installs deps)
HTTP_PROXY=http://127.0.0.1:7890 HTTPS_PROXY=http://127.0.0.1:7890 ./setup.sh -i

# Or manually (if setup.sh was interrupted):
./.venv/bin/pip install -r requirements.txt
./.venv/bin/pip install -e .
```

## Docker Alternative

```bash
# Only use if Docker Hub is directly accessible (not behind GFW without proxy config)
mkdir ft_userdata && cd ft_userdata
curl -O https://raw.githubusercontent.com/freqtrade/freqtrade/develop/docker-compose.yml
docker compose run --rm freqtrade create-userdir --userdir /freqtrade/user_data
```

## Create User Data & Config

```bash
# Create user data directory
python -m freqtrade create-userdir --userdir ~/ft_userdata/user_data

# Create config interactively (or copy template from references/)
python -m freqtrade new-config --config ~/ft_userdata/user_data/config-okx.json
```

## CLI Syntax Note (FreqTrade 2026.x)

In FreqTrade 2026.x dev, the `-c / --config` option must come **after** the subcommand, not before:

```bash
# Correct syntax (2026.x)
freqtrade trade -c config.json --userdir ./user_data
freqtrade list-exchanges -c config.json
freqtrade backtesting -c config.json --strategy SampleStrategy

# Wrong (fails with 'invalid choice: config.json')
freqtrade -c config.json trade
```

## Running with Proxy

FreqTrade uses `ccxt` for exchange connectivity. Configure per-exchange proxy in `config.json`:

```json
{
  "exchange": {
    "name": "okx",
    "ccxt_config": {
      "httpProxy": "http://127.0.0.1:7890"
    }
  }
}
```

## Common OKX Credential Pitfalls

When manually copying API keys from OKX, these errors are **extremely common**:

| Pitfall | Example | Fix |
|---------|---------|-----|
| Missing hex char | ca61f14c0c7 vs ca61ff14c0c7 | UUID last segment must be 12 hex chars |
| O/0 confusion | FECOO9D vs FEC009D | OKX secrets use 0 (zero), not O (letter) |
| l/1/I confusion | l/1/I in hex mixups | Double-check each character |
| Trailing whitespace | " key" or "key " | JSON values must be bare strings |
| ALL_PROXY vs httpProxy conflict | ALL_PROXY=socks5 with httpProxy set in JSON | unset HTTP_PROXY HTTPS_PROXY ALL_PROXY before running |

**Always test credentials before running live** with the bundled test script.

## Verifying Exchange API Credentials

After setting up the config, **always verify credentials before running live**.
Use the bundled test script `scripts/test-okx-connection.py`:

```bash
cd ~/ft_userdata/user_data
python3 /path/to/scripts/test-okx-connection.py
```

### Error code reference

| Code | Meaning | Action |
|------|---------|--------|
| 50111 | Invalid OK-ACCESS-KEY | Key was deleted or never confirmed — recreate on OKX |
| 50113 | Bad signature | Secret is wrong — copy again from OKX API page |
| 50114 | Wrong passphrase | Password/phrase doesn't match |

## FreqUI (Web Dashboard)

```bash
freqtrade webserver -c config.json --userdir ./user_data
```

Access at `http://127.0.0.1:8080`.

## Strategy Patterns

The bundled `templates/six-ma-cluster-strategy.py` evolved through 4 iterations. See the dedicated `v4-bearish-alignment-strategy` skill for the latest version with full documentation.

### Backtest results comparison (1h, BTC+ETH, 1000 USDT)

| Version | Total P&L | Win% | Short P&L | Max DD | Sharpe |
|---------|:---------:|:----:|:---------:|:------:|:------:|
| v1 cluster only | -4.82% | 26.1% | +2.99% | 6.67% | -2.11 |
| v2 + daily filter | -0.87% | 29.8% | +2.06% | 2.62% | -0.64 |
| v3 + bearish alignment | +1.44% | 38.8% | +4.36% | 4.24% | +0.56 |
| v4 + bear mode (shorts only) | +4.51% | 56.2% | +4.51% | 2.06% | +2.28 |

## Frequently Encountered Pitfalls

1. **Docker Hub blocked in China**: Use native Python install.
2. **Git clone via proxy**: Use `git -c http.proxy=... clone` to avoid timeout.
3. **setup.sh interruption**: Run `pip install -r requirements.txt && pip install -e .` to continue.
4. **CLI syntax**: 2026.x changed config option placement.
5. **ccxt proxy timeout quirk**: ccxt (v4.5.x) may time out on OKX even with `httpProxy` set, while `curl` works fine. Run the bundled test script to isolate.
6. **ALL_PROXY env var conflict**: Python respects ALL_PROXY. If set to socks5 while httpProxy is HTTP, the wrong proxy may be picked.
7. **merge_informative_pair column suffix**: When merging higher/lower timeframes in Freqtrade, `merge_informative_pair` adds the `_{timeframe}` suffix to all informative columns. E.g. merging 15m into 1m renames `trend_short` to `trend_short_15m`. Always use `dataframe.get(f"trend_short_{dtf}", False)` not `dataframe["trend_short"]`.
8. **populate_indicators bool assignment**: In Freqtrade, if you create a bool column (e.g. `enter_short`) in `populate_indicators`, trying to assign `(1, "tag")` to it in `populate_entry_trend` will fail with `TypeError: Invalid value '1' for dtype 'bool'`. Fix: use a different name for the indicator column (e.g. `v4_short`), then assign the entry signal in `populate_entry_trend`.

## Quick Start Command Reference

| Task | Command |
|------|---------|
| List supported exchanges | `freqtrade list-exchanges -c config.json` |
| List available trading pairs | `freqtrade list-markets -c config.json --print-list` |
| Download OHLCV data | `freqtrade download-data -t 5m --days 30 -c config.json` |
| Run backtest | `freqtrade backtesting --strategy SampleStrategy -c config.json` |
| List available strategies | `freqtrade list-strategies -c config.json --userdir ./user_data` |
| Start dry-run trade | `freqtrade trade -c config.json` (dry_run: true by default) |
| Start FreqUI dashboard | `freqtrade webserver -c config.json --userdir ./user_data` |
| Create new strategy | `freqtrade new-strategy --strategy MyStrategy` |

## PATH Setup

```bash
mkdir -p ~/bin
ln -sf ~/ft_userdata/freqtrade/.venv/bin/freqtrade ~/bin/freqtrade
cat >> ~/.bash_aliases << 'EOF'
export PATH="$HOME/bin:$PATH"
export HTTP_PROXY=http://127.0.0.1:7890
export HTTPS_PROXY=http://127.0.0.1:7890
EOF
source ~/.bash_aliases
```
