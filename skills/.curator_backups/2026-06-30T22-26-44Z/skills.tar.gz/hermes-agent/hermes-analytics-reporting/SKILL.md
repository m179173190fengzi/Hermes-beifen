---
name: hermes-analytics-reporting
description: Generate structured daily/weekly reports from Hermes internal data — token usage via hermes insights + state.db SQL queries, API provider balance checks, cost estimation with provider pricing, and formatted report delivery. For cron jobs and on-demand analytics.
---

# Hermes Analytics Reporting

Generate structured usage reports from Hermes internal data sources. This skill covers the pattern of aggregating data from multiple Hermes-internal sources (insights CLI, state.db SQLite store, API provider balance endpoints), estimating costs, and formatting the result as a structured report — typically delivered via cron jobs.

## Data Sources

### 1. `hermes insights --days N`
The primary high-level overview. Returns sessions count, message count, tool calls, input/output tokens, model breakdown, platform breakdown, tool usage, skill usage, activity patterns, and notable sessions.

### 2. `~/.hermes/state.db` (SQLite)
For per-session token breakdowns that `hermes insights` doesn't expose (e.g., top 5 sessions by tokens, cache hit/miss splits, per-session API calls).

**Key tables:**
- `sessions`: `id`, `title`, `started_at` (Unix timestamp), `model`, `input_tokens`, `output_tokens`, `cache_read_tokens`, `cache_write_tokens`, `message_count`, `tool_call_count`, `api_call_count`, `handoff_platform`, `estimated_cost_usd`

**Platform detection:**
- Cron sessions: `id LIKE 'cron_%'`
- Gateway/Telegram sessions: `handoff_platform` may be NULL even for non-CLI sessions; cross-reference with `hermes insights` platform breakdown for accuracy
- CLI: everything else

**Date filtering:** `started_at` is a Unix timestamp (float), not ISO date. Use Python's `datetime.now(timezone.utc).timestamp()` for range queries.

### 3. API Provider Balance

**DeepSeek:**
```bash
curl -s https://api.deepseek.com/user/balance \
  -H "Authorization: Bearer $DEEPSEEK_API_KEY"
```
Returns: `is_available`, `balance_infos[]` with `currency`, `total_balance`, `granted_balance`, `topped_up_balance`.

**OpenRouter:**
```bash
curl -s https://openrouter.ai/api/v1/auth/key \
  -H "Authorization: Bearer $OPENROUTER_API_KEY"
```

### 4. Provider Pricing (for Cost Estimation)

Fetch from provider docs. For **DeepSeek V4 Flash** (as of June 2026):

| Component | Price |
|-----------|-------|
| Input (cache hit) | $0.0028 / 1M tokens |
| Input (cache miss) | $0.14 / 1M tokens |
| Output | $0.28 / 1M tokens |

Source: https://api-docs.deepseek.com/quick_start/pricing

## DeepSeek Thinking/Reasoning Tokens — Critical Cost Factor

**For DeepSeek reasoning models** (deepseek-v4-flash, deepseek-r1, etc.) in default thinking mode, the "Total tokens" reported by `hermes insights` is NOT input + output. It includes **thinking tokens** (the chain-of-thought that the model generates internally before the visible response).

**Typical breakdown (actual data from cron sessions):**

| Component | Tokens | % of total | Billed at |
|-----------|--------|-----------|-----------|
| Input tokens | 93,321 | 9.5% | $0.14/1M (cache miss) |
| Output tokens (visible) | 13,542 | 1.4% | $0.28/1M |
| Thinking tokens (hidden) | 874,496 | 89.1% | $0.28/1M (output rate) |
| **Total billed** | **981,359** | **100%** | — |

**Thinking tokens are charged at the output rate** ($0.28/1M for DeepSeek V4 Flash). This means 89% of the token count is at the most expensive tier. A cost estimate that ignores thinking tokens will be **~10x too low**.

**Detecting thinking tokens from `hermes insights`:**

```
Total tokens (from "Models Used" section) - Input tokens - Output tokens = Thinking tokens
981,359 - 93,321 - 13,542 = 874,496 thinking tokens
```

The `state.db` does NOT currently store thinking tokens in a separate column — they are baked into the provider-side billing but not exposed in `sessions.*_tokens` columns. Use the subtraction method above.

**To reduce thinking token cost:**
- Switch to **non-thinking mode** for simple tasks: `hermes config set model.thinking_mode false` (DeepSeek V4 Flash supports both modes)
- For cron jobs with deterministic execution (data collection, formatting, simple RAG), non-thinking mode can eliminate 90% of token cost
- Per-model, not global — set per-cron-job via `--thinking false` or cron config

## Cost Estimation Formula

### Without thinking tokens (non-reasoning models or thinking disabled):

```
cache_hit_cost  = (cache_read_tokens / 1_000_000) * cache_hit_price
cache_miss_cost = (input_tokens / 1_000_000) * cache_miss_price
output_cost     = (output_tokens / 1_000_000) * output_price
total_cost      = cache_hit_cost + cache_miss_cost + output_cost
cache_hit_rate  = cache_read_tokens / (input_tokens + cache_read_tokens)
```

### With thinking tokens (DeepSeek reasoning models, default mode):

```
# thinking_tokens = total_tokens - input_tokens - output_tokens
# or from provider API: usage.completion_tokens_details.thinking_tokens

cache_hit_cost    = (cache_read_tokens / 1_000_000) * cache_hit_price
cache_miss_cost   = (input_tokens / 1_000_000) * cache_miss_price
output_cost       = (output_tokens / 1_000_000) * output_price
thinking_cost     = (thinking_tokens / 1_000_000) * output_price  # billed at output rate!
total_cost        = cache_hit_cost + cache_miss_cost + output_cost + thinking_cost
```

For DeepSeek V4 Flash:
- Cache hit rate is typically very high (~97%) for repeated cron sessions with identical system prompts
- Thinking token ratio varies by task complexity. Cron jobs reporting structured data: ~5-10x output tokens. Complex reasoning tasks: 20-50x+

## Report Format Template

```\n📊 Token 消耗日报\n\n今日总消耗：{total_tokens} tokens（含推理思考）\n- 输入 tokens（缓存未命中）：{input_tokens:,}\n- 输出 tokens（可见回复）：{output_tokens:,}\n- 推理思考 tokens：{thinking_tokens:,}（占 {thinking_pct}%，按输出费率计费）\n- 缓存命中 tokens（输入缓存，低费率）：{cache_hit_tokens:,}\n- 缓存命中率：{cache_hit_rate}% 🔥\n\n按模型分：\n- {model_name}: {tokens:,} tokens（{session_count} 个会话）\n\n按平台分：\n- {platform}: {session_count} 个会话 · {msg_count} 条消息 · {tokens:,} tokens\n\n按会话分（Top 5）：\n1. {session_title} — {tokens:,} tokens · {msgs} 条消息 · {calls} 次工具调用\n2. ...\n\n费用估算：\n| 项目 | Tokens | 单价 | 费用 |\n|------|--------|------|------|\n| 输入（缓存命中） | {n:.2f}M | ${price}/M | ≈ ${cost} |\n| 输入（缓存未命中） | {n:.2f}M | ${price}/M | ≈ ${cost} |\n| 输出 | {n:.3f}M | ${price}/M | ≈ ${cost} |\n| 推理思考 ⚠️ | {n:.3f}M | ${price}/M（输出率） | ≈ ${cost} |\n| 合计 | | | **≈ ${total} / ≈ ¥{total_cny}** |\n\nAPI Key 余额：{balance} {currency}（约 ${balance_usd}）\n- 按今日消耗速率（约 ¥{daily_spend}/天），余额可维持约 {days_remaining} 天\n- 建议：如 cron 任务无需深度推理，切至非 thinking 模式可节省 ~90% 成本\n```

All headings use emoji headers (📊, 💰, 📝). Use Chinese for user-facing report text.

## Clock and Timezone Awareness

When running as a cron job:
- `datetime.now(timezone.utc)` gives UTC time
- The Hermes insights CLI uses localtime for its `--days` display
- `state.db` stores `started_at` as UTC Unix timestamps (floats)
- When querying state.db, use UTC timestamp ranges to match `--days 1`

## Pitfalls

- **`hermes insights` reports a different "Total tokens" than the sum of state.db.** The insights tool may include or exclude cache tokens differently from the raw DB columns. The DB `cache_read_tokens` column holds the tokens served from provider cache (billed at lower rate, not free). Cross-referencing both sources is recommended.
- **Thinking tokens make "Total tokens" misleading.** For DeepSeek reasoning models, `hermes insights` "Total tokens" = input + output + thinking tokens. The state.db `input_tokens` + `output_tokens` will sum to much less than the model's total. Always subtract to find thinking tokens before estimating cost — ignoring them leads to ~10x underestimation.
- **`handoff_platform` is often NULL** for Telegram sessions. The insights CLI has better platform detection. Use insights for platform totals and DB for session-level detail.
- **Balance API keys** are in `~/.hermes/.env`, not in environment variables. Read them from the file or source them.
- **First-run pricing lookup** may require scraping the provider docs page. Cache the prices in the skill or reference doc to avoid re-scraping every time.
- **Rounding**: cost estimations are approximate — provider rounding differs from naive division. Add a disclaimer.

## See Also

- `references/hermes-token-report.md` — Complete worked example: token usage report with DB queries and cost estimation
- `references/deepseek-thinking-tokens-cost.md` — DeepSeek thinking token cost factor: detection formula, raw data from actual sessions, and mitigation (used when `hermes insights` "Total tokens" hugely exceeds input+output)
- `hermes-agent` skill (bundled) — `hermes insights` CLI reference and session management
- `cron-state-persistence` — State persistence for delta/diff cron jobs
