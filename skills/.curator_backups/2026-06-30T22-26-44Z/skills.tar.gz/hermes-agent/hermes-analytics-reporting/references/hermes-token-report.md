# Token Usage Report — Worked Example

Generated from a real cron session on 2026-06-28. Complete SQL queries, balance checks, and pricing used to produce the daily token consumption report.

## Data Collection Steps

### Step 1: High-Level Overview

```bash
hermes insights --days 1
```

This gives sessions, messages, tool calls, input/output tokens per model and platform, tool usage heatmap, skill loads, and activity patterns.

**Limitation:** Does not expose per-session token counts or cache hit/miss splits for the top sessions.

**Note:** For DeepSeek reasoning models, the reported "Total tokens" includes thinking/reasoning tokens. See `references/deepseek-thinking-tokens-cost.md` for the critical cost factor.

### Step 2: Per-Session Breakdown (state.db)

```python
import sqlite3, os
from datetime import datetime, timezone, timedelta

db_path = os.path.expanduser("~/.hermes/state.db")
conn = sqlite3.connect(db_path)
conn.row_factory = sqlite3.Row

now = datetime.now(timezone.utc)
start_ts = (now - timedelta(days=1)).timestamp()
end_ts = now.timestamp()

# Top 5 sessions by total tokens (input + output + cache)
cursor = conn.execute("""
    SELECT id, title,
           input_tokens, output_tokens, cache_read_tokens,
           (COALESCE(input_tokens,0) + COALESCE(output_tokens,0) + COALESCE(cache_read_tokens,0)) as total,
           message_count, tool_call_count, model
    FROM sessions 
    WHERE started_at BETWEEN ? AND ?
        AND (COALESCE(input_tokens,0) + COALESCE(output_tokens,0) + COALESCE(cache_read_tokens,0)) > 0
    ORDER BY total DESC
    LIMIT 5;
""", (start_ts, end_ts))

# Platform breakdown (cron detection by ID prefix)
cursor = conn.execute("""
    SELECT 
        CASE 
            WHEN id LIKE 'cron_%' THEN 'cron'
            WHEN handoff_platform IS NOT NULL AND handoff_platform != '' THEN handoff_platform
            ELSE 'cli'
        END as platform,
        COUNT(*) as sessions,
        SUM(COALESCE(input_tokens,0)) as inp,
        SUM(COALESCE(output_tokens,0)) as out,
        SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0) + COALESCE(cache_read_tokens,0)) as total
    FROM sessions 
    WHERE started_at BETWEEN ? AND ?
    GROUP BY platform
    ORDER BY total DESC;
""", (start_ts, end_ts))

# Model breakdown
cursor = conn.execute("""
    SELECT model,
        SUM(COALESCE(input_tokens,0)) as inp,
        SUM(COALESCE(output_tokens,0)) as out,
        SUM(COALESCE(input_tokens,0) + COALESCE(output_tokens,0) + 
            COALESCE(cache_read_tokens,0)) as total
    FROM sessions 
    WHERE started_at BETWEEN ? AND ?
    GROUP BY model
    ORDER BY total DESC;
""", (start_ts, end_ts))

conn.close()
```

**Note:** Cross-reference platform totals with `hermes insights` output. The insights CLI has more accurate platform detection than the SQL heuristic above, especially for Telegram sessions where `handoff_platform` is often NULL in the DB.

### Step 3: API Key Balance Check

**DeepSeek:**
```bash
curl -s https://api.deepseek.com/user/balance \
  -H "Authorization: Bearer $(grep DEEPSEEK_API_KEY ~/.hermes/.env | head -1 | cut -d= -f2-)"
```

Response format:
```json
{
  "is_available": true,
  "balance_infos": [
    {
      "currency": "CNY",
      "total_balance": "6.08",
      "granted_balance": "0.00",
      "topped_up_balance": "6.08"
    }
  ]
}
```

**OpenRouter:**
```bash
curl -s https://openrouter.ai/api/v1/auth/key \
  -H "Authorization: Bearer $(grep OPENROUTER_API_KEY ~/.hermes/.env | head -1 | cut -d= -f2-)"
```

### Step 4: Provider Pricing Lookup

**DeepSeek V4 Flash** pricing (sourced from https://api-docs.deepseek.com/quick_start/pricing):

| Component | Price (USD) |
|-----------|-------------|
| 1M input tokens (cache hit) | $0.0028 |
| 1M input tokens (cache miss) | $0.14 |
| 1M output tokens (incl. thinking) | $0.28 |

Other model pricing available at the same URL. For DeepSeek reasoning models,
thinking tokens are billed at the output rate — see `references/deepseek-thinking-tokens-cost.md`.

### Step 5: Cost Calculation

```python
# Without thinking tokens (non-reasoning models)
input_miss  = total_input_tokens      # ~947K
cache_hit   = total_cache_read_tokens  # ~33.1M
output      = total_output_tokens      # ~103K

cache_hit_cost  = (cache_hit / 1_000_000) * 0.0028   # ≈ $0.093
cache_miss_cost = (input_miss / 1_000_000) * 0.14     # ≈ $0.133
output_cost     = (output / 1_000_000) * 0.28         # ≈ $0.029
total_usd       = cache_hit_cost + cache_miss_cost + output_cost  # ≈ $0.26
total_cny       = total_usd * 7.25                    # ≈ ¥1.86 (at ~7.25 USD/CNY)

cache_hit_rate  = cache_hit / (input_miss + cache_hit)  # ~97.2%

# WITH thinking tokens (DeepSeek reasoning models):
# thinking_tokens = total_from_insights - input_tokens - output_tokens
# thinking_cost = (thinking_tokens / 1_000_000) * output_price
# total_cost = cache_hit_cost + cache_miss_cost + output_cost + thinking_cost

# Days remaining (DeepSeek balance in CNY)
balance_cny = 6.08
days_remaining = balance_cny / total_cny  # ≈ 3.3 days
```

## Report Format

The final report uses the following structure (Chinese, emoji headers):

```
📊 Token 消耗日报

今日总消耗：33,906,050 tokens

按模型分：
- DeepSeek V4 Flash: 33,906,050 tokens

按平台分：
- Telegram: 26,916,618 tokens
- CLI: 2,344,018 tokens
- Cron: 4,645,414 tokens

按会话分（消耗最多的前5个会话）：
1. Mistake Correction Needed - 26,916,618 tokens
...

费用估算：
| 项目 | Tokens | 单价 | 费用 |
|------|--------|------|------|
| 输入（缓存命中） | 33.14M | $0.0028/M | ≈ $0.093 |
...

API Key 余额：6.08 CNY（约 $0.84）
- 按今日消耗速率（约 ¥1.86/天），余额可维持约 3 天
- 均为充值余额，无赠送余额

📝 总结与建议
...
```

## Key Numbers from Sample Run (2026-06-28)

| Metric | Value |
|--------|-------|
| Total sessions | 11 |
| Total messages | 655 |
| Input tokens (miss) | 947,678 |
| Output tokens | 102,875 |
| Cache read tokens | 33,138,176 |
| Cache hit rate | 97.2% |
| Total (all incl.) | 34,193,407 |
| Estimated cost | ~$0.26 / ~¥1.86 |
| DeepSeek balance | 6.08 CNY |
| Days remaining | ~3 |

## Pitfalls

- **Cache token counting:** `cache_read_tokens` in the DB represents tokens served from provider-side prompt caching — they are billed at a reduced rate, not free. Do not subtract them from the total; instead, calculate cost at the lower rate.
- **Time zone:** `hermes insights --days 1` uses localtime. `state.db started_at` is UTC. Match by using UTC timestamps with a 1-day range.
- **Zero-token sessions:** Sessions created by `hermes model` or `hermes setup` may have 0 tokens and 0 messages. Filter them out with `total_tokens > 0`.
- **Thinking tokens (DeepSeek reasoning models):** The "Total tokens" from insights heavily inflates the visible input+output count. Always subtract to find thinking tokens. 89% of today's DeepSeek cost was from thinking tokens alone.
- **Balance curl command:** Use `grep DEEPSEEK_API_KEY ~/.hermes/.env | head -1 | cut -d= -f2-`. Never a truncated form. The env file may have multiple API key entries; `head -1` picks the first (usually the main one).
- **Cost disclaimer:** Provider pricing changes. Cache hit ratio varies by session (repeated cron sessions with identical system prompts achieve very high hit rates; one-off interactive sessions may be much lower). Thinking token ratio varies by task complexity.
